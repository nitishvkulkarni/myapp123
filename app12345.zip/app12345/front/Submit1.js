import React from 'react'

export default function Submit1() {
  return (
    <div className="container m-5 p-5">

        <h2> Problem Submitted successfully </h2>  
           
       </div>

       
  )
}
