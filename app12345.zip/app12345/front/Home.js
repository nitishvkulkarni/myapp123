import React from 'react'
import './index.css'

export default function Home() {
  return (
    <div className="container-fluid mt-5 pt-5">
      <div className="row">
        <div className='col-md-12'>
          <h2 className='text-center'> Welcome to XYZ Ltd Customer Care </h2>  
          <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6Y0R3JZA1Xc_7jtHlBXt7Qoy-W1sd_kFam3wQgpnqMg&s' alt="welcome" className='resp'></img>
  
        </div> 
      </div>  
    </div>

       
  )
}
