import './App.css';
import FormSub from './FormSub';
import Submit from './Submit.js';
import Navbar from './Navbar';
import Login from './LogIn.js';
import { BrowserRouter, Routes,  Route,} from "react-router-dom";
import Dashbord from './Dashbord.js';
import ProblemSub from './ProblemSub.js';
import DashbordSupport from './Dashbord-Support.js';
import DashbordAdmin from './Dashbord-Admin.js';
import LoginA from './LoginAdmin.js';
import Submit1 from './Submit1.js';
import ReplySub from './ReplySub.js';
import Submit2 from './Submit2.js';
import DashbordC from './Dashbord-C.js';
import StatusC from './StatusC.js';
import StatusC1 from './Status-C1.js';
import Feedback from './Feedback1.js';
import Submit3 from './Submit3.js';
import Home from './Home.js';






function App() {
  return (
    <div className="App">
 

<BrowserRouter>
      <Navbar/>
      
     
    
      
       
      <div className="container my-3"> 
        <Routes>
        
          <Route path=""  element={<Home/>} />

          <Route path="/a"  element={<FormSub/>} />
          
          <Route path="/success"  element={<Submit/>} />

          <Route path="/success1"  element={<Submit1/>} />

          <Route path="/success2"  element={<Submit2/>} />

          <Route path="/success3"  element={<Submit3/>} />

          <Route path="/login"  element={<Login/>} />

          <Route path="/a-login"  element={<LoginA/>} />

          <Route path="/welcome"  element={<Dashbord/>} />

          <Route path="/welcome1"  element={<DashbordC/>} />

          <Route path="/b"  element={<ProblemSub/>} />

          <Route path="/e"  element={<ReplySub/>} />

          <Route path="/c"  element={<DashbordSupport/>} />

          <Route path="/i"  element={<DashbordAdmin/>} />

          <Route path="/f"  element={<StatusC/>} />

          <Route path="/g"  element={<StatusC1/>} />

          

          <Route path="/h"  element={<Feedback/>} />
          

          


        
        </Routes>
     </div>
    </BrowserRouter>

    </div>
  );
}


export default App;
