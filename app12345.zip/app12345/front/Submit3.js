import React from 'react'

export default function Submit3() {
  return (
    <div className="container m-5 p-5">

        <h2> Feedback Submitted successfully </h2>  
           
       </div>

       
  )
}
