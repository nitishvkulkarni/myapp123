// import React from 'react'
// import { useState } from 'react';
// import { useNavigate } from 'react-router-dom'; 
// import axios from 'axios';

// export default function FormSub() {

//     const navigate = useNavigate();
//     const [name,setName] = useState('');
//     const [number,setNumber] = useState('');
//     const [email,setEmail] = useState('');
//     const [password,setPassword] = useState('');
//     const [message,setMessage] = useState('');
   
   
//     const upLoad = async() => {
       
       
//         let fData = new FormData();
//         fData.append('name', name);
//         fData.append('number', number);
//         fData.append('email', email);
//         fData.append('password', password);

      
//         const responce = await axios.post("http://localhost/task/api/user-reg.php", fData, { 
//           headers: {'Content-Type':"multipart/form-data"},
//         } );

//         if (responce.data.success)
//          {
//           setMessage(responce.data.success);
//           setTimeout (()=>
//           {
//             navigate ('/success')
//           }, 500)
          
//         }
     
     
//     }

//     const handleSubmit = async(e) => {
//       e.preventDefault();
//       await upLoad();
//     }
//   return (
//     <div className="container m-4">
//       <div className="vh-100 gradient-custom">
//        <div className="mask d-flex align-items-center h-100 gradient-custom-3">
//          <div className="container h-100">
//           <div className="row d-flex justify-content-center align-items-center h-100">
//            <div className="col-md-12">
         
//              <div className="card-body p-5">
//                 <h1 className="text-center mb-5"> User Register  </h1>
//                 <form onSubmit= { handleSubmit }>
//                 <div className="form-outline mb-4">
//                     <label className="form-label" for="title"> Name </label>
//                     <input type="text" className="form-control form-control-lg"  onChange={(e) => setName(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                     <label className="form-label" for="authorname"> Number</label>
//                     <input type="varchar" className="form-control form-control-lg"  onChange={(e) => setNumber(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                     <label className="form-label" for="description"> Email </label>
//                     <input type="varchar" className="form-control form-control-lg" onChange={(e) => setEmail(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                   <label className="form-label" for="link"> Password </label>
//                     <input type="varchar" className="form-control form-control-lg"  onChange={(e) => setPassword(e.target.value)} />
//                   </div>

                
//                   <div className="d-flex justify-content-center">
//                   <input type="button" className="btn btn-warning" name="submit" id="submit" value="Submit" onClick={upLoad} />
//                   </div>
 
                  
 
//                 </form>
//              </div>
//             </div>
//            </div>
//           </div>
//         </div>
//       </div>
//     </div>

      
  
//   )
// }

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import axios from 'axios';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    try {
      const response = await fetch('http://yourbackend.com/login.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });
      const data = await response.json();
      if (data.success) {
        // Handle successful login
        console.log('Login successful');
      } else {
        // Handle login error
        setError(data.message);
      }
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <div>
      <h2>Login</h2>
      {error && <p>{error}</p>}
      <form>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="button" onClick={handleLogin}>
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;
