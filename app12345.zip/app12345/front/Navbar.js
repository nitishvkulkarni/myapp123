import React from 'react'
import { Link } from 'react-router-dom';


export default function Navbar() {
  return (
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <div class="container-fluid">
          <Link className="navbar-brand" href=""> Nvk Customer Support </Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            <ul className="navbar-nav">
          
              <li className="nav-item">
                <Link className="nav-link" to="/a"> User Register </Link>
              </li>
           
              <li className="nav-item">
                <Link className="nav-link" to="login"> Login </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="a-login"> Admin Login </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  )
}
