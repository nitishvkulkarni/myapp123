import React, { useState, useEffect } from 'react';
import "./card.css";
import {Link} from 'react-router-dom';


function Posts() {
    const [posts, setPosts] = useState([]);
    // const [loading, setLoading] = useState(true);
    
    useEffect(()=>{
        fetch('http://localhost/test/api/product.php/')
        .then(response => response.json())
        .then(json => setPosts(json))
        // .then(json => setLoading(false))
    }, []);
    
    return (
        <div className="posts">
            
            <div>
                { posts.map(get => (
                    <div className="card mt-5" key={get.id}>
                         <p> Title: {get.title}</p>
                         <Link to={get.link}> <img src={`http://localhost/test/images/${get.pfile}`} /> </Link>
                           
                            <p> Author: {get.authorname}</p>
                            <div className='desc'> <p>{get.description}</p> </div>
                            <p> Link: {get.link} </p>
                            <p>Publish Date: {get.date}</p>
                            <p> <Link className='btn btn-warning rounded-pill' to={get.link}> View more </Link> </p>
                        
                    </div>
                )) }
            </div>
        </div>
    )
}
export default Posts