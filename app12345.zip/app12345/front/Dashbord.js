import React from 'react'
import { Link } from 'react-router-dom'

export default function Dashbord() {
  return (
    <div className="container m-5 p-5">

        <h2> Welcome User </h2>  

      
      <Link to="/b"> Submit Problem </Link> <br/>

      <Link to="/f"> Know Status </Link>
           
       </div>

       
  )
}
