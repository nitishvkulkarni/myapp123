const list = [
    {
      id: 1,
      title: "100% Employment",
      author: " Mr Nitish V Kulkarni",
      description: "This Blog is based on problem of unemployment specially who are willing to work but not getting opportinity ",
      img: "https://blog.ipleaders.in/wp-content/uploads/2017/05/income-tax-3.jpg",
      dtpub: "01/09/2023",
      href: "/a",
    },
    {
      id: 2,
      title: "Education for Everyone",
      author: "Mr D S Patil",
      description: "This Blog is based on problem of illiteracy specially who are willing to learn but not getting facility ",
      img: "https://static.wixstatic.com/media/d7a47e_475e30421f284d4882d682980b17ae7e~mv2.png/v1/fill/w_300,h_300,al_c/d7a47e_475e30421f284d4882d682980b17ae7e~mv2.pngg",
      dtpub: "02/09/2023",
      href: "/b",
      
    },
    {
      id: 3,
      title: "Road Development",
      author: " M V Deshpande",
      description: "This Blog is based on bad quality of roads specially who are living in small towns facing this problem ",
      img: "https://media.istockphoto.com/id/1263860522/photo/fly-over.jpg?s=612x612&w=0&k=20&c=ArcTiXNXUgjrdE9kyzasDTJUzFXvPyq9tUe_GnHDzA8=",
      dtpub: "03/09/2023",
      href: "/c",
      
    },
    {
      id: 4,
      title: "Waste Management",
      author: "Mr Ajay G Kumar",
      description: "This Blog is based on poor waste management sytem specially in metro cities this is big problem",
      img: "https://www.dqindia.com/wp-content/uploads/2018/03/waste-management.jpg",
      dtpub: "04/09/2023",
      href: "/d",
      
    },
    {
      id: 5,
      title: " Startup New Business ",
      author: " Mr R K Singh ",
      description: "This article is based on challange faced by people in starting new venture specially financial problems" ,
      img: "https://startupscouncilofindia.com/img/startup1.jpg",
      dtpub: "05/09/2023",
      href: "/e",
      
    },
    {
      id: 6,
      title: "Transperant Administration",
      author: " Mr Kishor S Gaikwad",
      description: "This Blog is based on challanges faced by common people while getting work done from goverment employees",
      img: "https://png.pngtree.com/png-vector/20221207/ourmid/pngtree-say-no-to-corruption-png-image_6513486.png",
      dtpub: "06/09/2023",
      href: "/f",
      
    },

    {
      id: 7,
      title: "Crime Free Society",
      author: "Mr Rajaram V Shinde ",
      description: "Blog tells us how to prevent youth from being criminals specially poor youngsters",
      img: "https://www.miamisprings-fl.gov/sites/default/files/styles/gallery500/public/imageattachments/police/page/26476/stop_crime.jpg?itok=sfjA8JUt",
      dtpub: "07/09/2023",
      href: "/g",
      
    },
    {
      id: 8,
      title: "Woman Social Issues",
      author: "Mrs Aruna S Shetty",
      description: "This blog is based on problems faced by women specially rural woman facing poverty & unemployment ",
      img: "https://feminisminindia.com/wp-content/uploads/2020/09/1_hzmpX1ruHDWZbCRSkDlbag-737x1024.jpeg",
      dtpub: "08/09/2023",
      href: "/h",
      
    },
    {
      id: 9,
      title: "Good Public Healthcare",
      author: "Dr Niranjan J Saksena",
      description: "This blog is based on how to make government hospital more efficient & poor people will get quality treatment ",
      img: "https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX27029904.jpg",
      dtpub: "09/09/2023",
      href: "/i",
      
    },
    {
      id: 10,
      title: "Excellent Public Transport",
      author: "Mr Haridas R Sasane",
      description: "This blog is based on traffic jams faced by people & how use of public transport can solve problem",
      img: "https://metrorailtoday.com/assets/uploads/gallary/20220221140010.jpg",
      dtpub: "10/09/2023",
      href: "/j",
      
    }
    
];

export default list;
