// import React from 'react'
// import { useState } from 'react';
// import { useNavigate } from 'react-router-dom'; 
// import axios from 'axios';

// export default function QuerySub() {

//     const navigate = useNavigate();
//     const [name,setName] = useState('');
//     const [model,setModel] = useState('');
//     const [problem,setProblem] = useState('');
//     const [number,setNumber] = useState('');
//     const [message,setMessage] = useState('');
   
   
//     const upLoad = async() => {
       
       
//         let fData = new FormData();
//         fData.append('name', name);
//         fData.append('model', model);
//         fData.append('problem', problem);
//         fData.append('number', number);

      
//         const responce = await axios.post("http://localhost/task/api/user-reg.php", fData, { 
//           headers: {'Content-Type':"multipart/form-data"},
//         } );

//         if (responce.data.success)
//          {
//           setMessage(responce.data.success);
//           setTimeout (()=>
//           {
//             navigate ('/success')
//           }, 500)
          
//         }
     
     
//     }

//     const handleSubmit = async(e) => {
//       e.preventDefault();
//       await upLoad();
//     }
//   return (
//     <div className="container m-4">
//       <div className="vh-100 gradient-custom">
//        <div className="mask d-flex align-items-center h-100 gradient-custom-3">
//          <div className="container h-100">
//           <div className="row d-flex justify-content-center align-items-center h-100">
//            <div className="col-md-12">
         
//              <div className="card-body p-5">
//                 <h1 className="text-center mb-5"> User Register  </h1>
//                 <form onSubmit= { handleSubmit }>
//                 <div className="form-outline mb-4">
//                     <label className="form-label" for="title"> Name </label>
//                     <input type="text" className="form-control form-control-lg"  onChange={(e) => setName(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                     <label className="form-label" for="description"> Model </label>
//                     <input type="varchar" className="form-control form-control-lg" onChange={(e) => setModel(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                   <label className="form-label" for="link"> Problem </label>
//                     <input type="varchar" className="form-control form-control-lg"  onChange={(e) => setProblem(e.target.value)} />
//                   </div>
//                   <div className="form-outline mb-4">
//                     <label className="form-label" for="authorname"> Number</label>
//                     <input type="varchar" className="form-control form-control-lg"  onChange={(e) => setNumber(e.target.value)} />
//                   </div>
                 
                
//                   <div className="d-flex justify-content-center">
//                   <input type="button" className="btn btn-warning" name="submit" id="submit" value="Submit" onClick={upLoad} />
//                   </div>
 
                  
 
//                 </form>
//              </div>
//             </div>
//            </div>
//           </div>
//         </div>
//       </div>
//     </div>

      
  
//   )
// }
