import React from 'react'
import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function DashbordAdmin() {
  const [posts, setPosts] = useState([]);
  // const [loading, setLoading] = useState(true);
  
  useEffect(()=>{
      fetch('http://localhost/task/api/prob_reg.php/')
      .then(response => response.json())
      .then(json => setPosts(json))
      // .then(json => setLoading(false))
  }, []);
  
  

  return (
    <div>
        
        <div className="mt-5 pt-5">
            { posts.map(get => (
                <div className="card mt-5" key={get.id}>
                      <p> Number: {get.number}</p>
                       
                        <p> Model: {get.model}</p>
                  
                        <p> problem: {get.problem} </p>
                        <p> Reply: {get.reply}</p>
                        <p> Reply: {get.feedback}</p>
                        {/* <p> <Link className='btn btn-warning rounded-pill' to="/e" target='_blank'> Reply </Link> </p> */}
                    
                </div>
            )) }
        </div>
    </div>
)
}
