import React from 'react'

export default function Submit() {
  return (
    <div className="container m-5 p-5">

        <h2>User Registered successfully </h2>  
           
       </div>

       
  )
}
