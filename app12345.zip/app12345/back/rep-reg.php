<?php 
    header('Access-Control-Allow-Origin: *');
     
    $conn = new mysqli("localhost","root","","users_admin");
     
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
        exit();
    }
    else{
        $number = $_POST['number'];
        $model = $_POST['model'];
        $problem = $_POST['problem'];
        $reply = $_POST['reply'];
        
        
        
        
         
        $sql = "INSERT INTO problem_reg(reply) VALUES('$reply');";
        $res = mysqli_query($conn, $sql);
         
        if($res){
            
            echo json_encode(["success"=>"Inserted Successfully"]);
        }
        else{
            
            echo json_encode(["failed"=>"Not Inserted!"]);
        }
        $conn->close();
    }
?>