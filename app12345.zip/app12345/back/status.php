<?php
error_reporting(E_ALL);
ini_set('display_errors',1);
header("Access-Control-Allow-Origin:* ");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

$db_conn= mysqli_connect("localhost","root", "", "users_admin");
if($db_conn===false)
{
  die("ERROR: Could Not Connect".mysqli_connect_error());
}

$method = $_SERVER['REQUEST_METHOD'];

switch($method)
{
    case "GET": 
      $path= explode('/', $_SERVER['REQUEST_URI']);

      if(isset($path[4]) && is_numeric($path[4]))
      {
        echo "Get Api Single Row"; die;
      } else {
       
       $destination= $_SERVER['DOCUMENT_ROOT']."/test"."/";
       $allblog= mysqli_query($db_conn, "SELECT * FROM prob_reg");
       if(mysqli_num_rows($allblog) > 0)
       {
          while($row= mysqli_fetch_array($allblog))
          {
           $json_array["blogdata"][]= array( 
           "number"=>$row["number"],
           "model"=>$row["model"],
           "problem"=>$row["problem"],
          //  "link"=>$row["link"],
          //  "pfile"=>$row["pfile"],
           "reply"=>$row["reply"]
          );
          }
          echo json_encode($json_array["blogdata"]);
          return;
       } else {
        echo json_encode(["result"=>"please check the Data"]);
        return;
       }


      }

    case "POST":
      if(isset($_FILES['pfile']))
      {      
        $title= $_POST['title'];
        $authorname= $_POST['authorname'];
        $description= $_POST['description'];
        $link= $_POST['link'];
        $pfile= $_FILES['pfile']['name'];
        $pfile_temp= $_FILES['pfile']['tmp_name'];
        $destination= $_SERVER['DOCUMENT_ROOT'].'/test/images'."/".$pfile;

        $result= mysqli_query($db_conn,"INSERT INTO blogging(title, authorname, description, link, pfile)
        VALUES('$title','$authorname', '$description', '$link', '$pfile')");

        if($result)
        { 
          move_uploaded_file($pfile_temp, $destination);
          echo json_encode(["success"=>"Product Inserted Successfully"]);
           return;
        } else{
          echo json_encode(["success"=>"Product Not Inserted!"]);
           return;
        }

      } else{
        echo json_encode(["success"=>"Data not in Correct Format"]);
        return;
      }
        
    break;

    case "DELETE":
           
    break;

          

}


?>