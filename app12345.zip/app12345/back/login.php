<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header('Access-Control-Allow-Headers: X-Requested-With');
     
    $conn = new mysqli("localhost","root","","users_admin");
     
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
        exit();
    }

    else{
        $email = $_POST['email'];
        $password = $_POST['password'];

        $email = stripcslashes($email);  
        $password = stripcslashes($password);  
        $email = mysqli_real_escape_string($conn, $email);  
        $password = mysqli_real_escape_string($conn, $password);  
      
            // $sql = "SELECT * FROM user_reg  WHERE email='$email' AND password='$password'";
            
            // $res = $conn->query($sql);

            $sql = "select *from user_reg where email = '$email' and password = '$password'";  
            $result = mysqli_query($conn, $sql);  
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
            $count = mysqli_num_rows($result);      
    // if($res){
            
    //     echo json_encode(["success"=>"login success"]);
    // }
    // else{
        
    //     echo json_encode(["invalid"=>"login fail"]);
    // }

    if($count == 1){  
        echo json_encode(["success"=>"login success"]);;  
    }  
    else{  
        echo json_encode(["invalid"=>"login fail"]);  
    }     
    $conn->close();
        
}
?>