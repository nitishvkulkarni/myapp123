<?php 
    header('Access-Control-Allow-Origin: *');
     
    $conn = new mysqli("localhost","root","","users_admin");
     
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
        exit();
    }
    else{
        $reply = $_POST['reply'];
        $feedback = $_POST['feedback'];
      
         
        $sql = "INSERT INTO prob_reg(feedback) VALUES('$feedback');";
        $res = mysqli_query($conn, $sql);
         
        if($res){
            
            echo json_encode(["success"=>"Inserted Successfully"]);
        }
        else{
            
            echo json_encode(["sorry"=>"error"]);
        }
        $conn->close();
    }
?>