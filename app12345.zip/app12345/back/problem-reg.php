<?php 
    header('Access-Control-Allow-Origin: *');
     
    $conn = new mysqli("localhost","root","","users_admin");
     
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
        exit();
    }
    else{
        $name = $_POST['name'];
        $model = $_POST['model'];
        $problem = $_POST['problem'];
        $number = $_POST['number'];
        
        
        
         
        $sql = "INSERT INTO prob_reg(name, model, problem, number) VALUES('$name','$model', '$problem', '$number');";
        $res = mysqli_query($conn, $sql);
         
        if($res){
            
            echo json_encode(["success"=>"Inserted Successfully"]);
        }
        else{
            
            echo json_encode(["failed"=>"Not Inserted!"]);
        }
        $conn->close();
    }
?>