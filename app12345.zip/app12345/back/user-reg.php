<?php 
    header('Access-Control-Allow-Origin: *');
     
    $conn = new mysqli("localhost","root","","users_admin");
     
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
        exit();
    }
    else{
        $name = $_POST['name'];
        $number = $_POST['number'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        
         
        $sql = "INSERT INTO user_reg(name, number, email, password) VALUES('$name','$number','$email', '$password');";
        $res = mysqli_query($conn, $sql);
         
        if($res){
            
            echo json_encode(["success"=>"Product Inserted Successfully"]);
        }
        else{
            
            echo json_encode(["success"=>"Product Not Inserted!"]);
        }
        $conn->close();
    }
?>